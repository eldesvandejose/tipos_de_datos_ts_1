/* Declaramos dos operandos de tipo numérico, asignándole al primero un valor 
durante la declaración y al segundo un valor después de la declaración. */
let operando_1: number = 30;
let operando_2: number;
operando_2 = 2;
/* Declaramos una variable para el resultado de sumar los dos operandos anteriores. */
let resultado_suma: number = operando_1 + operando_2;
/* Volcamos los datos a la consola del navegador. */
console.log("El primer operando vale: ", operando_1);
console.log("El segundo operando operando vale: ", operando_2);
console.log("La suma de ambos vale: ", resultado_suma);
